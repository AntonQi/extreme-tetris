We recreated the popular 20th century game Tetris. The controls are very simple, use left and right to move left and right, and use up to rotate.

You earn points by clearing lines. The more lines you clear simotaniously, the more points you earn.

However, beware of the twists of EXTREME TETRIS:

First, the blocks move a lot faster than they usually do.
Second, we disabled holding blocks, similar to the orginal NES version of tetris
Third, holding the arrow keys to move won't work. You'll have to hypertap!
Fourth, whenever you clear a line, the next block summoned has 2 layers, and it's unrotatable! Play and adapt!
	If you clear more than 1 line at a time, then more layers are added. For example, if you clear 3 lines, then the next piece would be 4 stacks

These are the twists of EXTREME TETRIS, Good Luck and Have Fun!