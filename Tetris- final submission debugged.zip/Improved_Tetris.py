'''
+---------------------------------+
|EXTREME TETRIS                   |
|By: Anton Qi, Alex Fan           |
|Most recent update: Jan 17, 2020 |
+---------------------------------|
'''


import pygame
import random
import os

# initalize pygame
pygame.init()

# drawing the game window and setting a name

win = pygame.display.set_mode((500, 700))
pygame.display.set_caption("EXTREME TETRIS")

# globalising and declaring variables

global scoreSTR
global gameboard
scoreSTR = 0

board01 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board02 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board03 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board04 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board05 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board06 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board07 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board08 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board09 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board10 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board11 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board12 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board13 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board14 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board15 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board16 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board17 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board18 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board19 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board20 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
board21 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

gameboard = [board01, board02, board03, board04, board05, board06, board07, board08, board09, board10, board11, board12, board13, board14, board15, board16, board17, board18, board19, board20, board21]

                    
# the main game loop

def mainGameLoop():

    run = True
    lines = 0
    runSpeed = 10
    blockId = random.randint(1, 7)
    finishedFalling = bool(False)
    unmovableLeft = False
    unmovableRight = False
    recentlyCleared = False
    level = 0
    score = 0
    linesCleared = 0
    currentRotation = 1
    board01 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board02 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board03 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board04 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board05 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board06 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board07 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board08 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board09 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board10 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board11 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board12 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board13 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board14 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board15 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board16 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board17 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board18 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board19 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board20 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    board21 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    
    gameboard = [board01, board02, board03, board04, board05, board06, board07, board08, board09, board10, board11, board12, board13, board14, board15, board16, board17, board18, board19, board20, board21]    

    # the actual loop
    while run:

        # setting the background

        backgroundImage = pygame.image.load(os.path.join('tetris_background.png'))

        win.blit(backgroundImage, (0, 0))

        # adding time delay and frame count

        pygame.time.delay(runSpeed)

        # allowing the user to exit the game

        events = pygame.event.get()

        for event in events:

            if event.type == pygame.QUIT:
                run = False

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_ESCAPE:
                    TitleScreen()
                    run = False

        # drawing the game board
        borderColor = pygame.Color(255, 255, 255)

        for i in range(20):
            pygame.draw.rect(win, borderColor, (150, 150 + 20*i, 200, 1))

        for i in range(11):
            pygame.draw.rect(win, borderColor, (150 + 20 * i, 150, 1, 380))

        # spawning tetrominoes

        # I piece
        if blockId == 1:
            board01[3] += 3
            board01[4] += 3
            board01[5] += 3
            board01[6] += 3
            recentlySummoned = True
            color = pygame.Color(0, 255, 255)
            rotationID = 1

        # J piece
        if blockId == 2:
            board01[3] += 3
            board01[4] += 3
            board01[5] += 3
            board02[5] += 3
            recentlySummoned = True
            color = pygame.Color(255, 165, 0)
            rotationID = 2

        # L piece

        if blockId == 3:
            board01[3] += 3
            board01[4] += 3
            board01[5] += 3
            board02[3] += 3
            recentlySummoned = True
            color = pygame.Color(0, 0, 255)
            rotationID = 3

        # O piece
        if blockId == 4:
            board01[4] += 3
            board01[5] += 3
            board02[4] += 3
            board02[5] += 3
            recentlySummoned = True
            color = pygame.Color(255, 255, 0)
            rotationID = 4

        # S piece
        if blockId == 5:
            board01[4] += 3
            board01[5] += 3
            board02[3] += 3
            board02[4] += 3
            recentlySummoned = True
            color = pygame.Color(0, 255, 0)
            rotationID = 5

        # Z piece
        if blockId == 6:
            board01[3] += 3
            board01[4] += 3
            board02[4] += 3
            board02[5] += 3
            recentlySummoned = True
            color = pygame.Color(255, 0, 0)
            rotationID = 6

        # T piece
        if blockId == 7:
            board01[4] += 3
            board02[3] += 3
            board02[4] += 3
            board02[5] += 3
            recentlySummoned = True
            color = pygame.Color(128, 0, 128)
            rotationID = 7

        # drawing the blocks

        for i in range(10):

            for j in range(20):

                if gameboard[j][i] >= 1:
                    pygame.draw.rect(win, color, (150 + 20*i, 150 + 20*j, 20, 20))

        # update display if it spawned a tetromino this round

        if recentlySummoned:

            pygame.display.update()
            recentlySummoned = False
            blockId = 9
            orientation = 1

        # ending the game

        for i in range(10):
            if board01[i] > 3:
                global scoreSTR
                endGame()
                run = False

        # clearing rows

        for i in range(20):
            if gameboard[i] == [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]:

                recentlyCleared = True
                gameboard[i] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
                lines += 1

                linesCleared += 1

                for j in range(i):

                    for k in range(10):
                        if gameboard[i-j][k] != 3:
                            gameboard[i-j][k] = gameboard[i-j-1][k]
                

        # scoring points
        
        if linesCleared == 1:
            score += 40 * (level + 1)

        elif linesCleared == 2:
            score += 100 * (level + 1)

        elif linesCleared == 3:
            score += 300 * (level + 1)

        elif linesCleared == 4:
            score += 1200 * (level + 1)
            lines += 4

            level = lines//10

        linesCleared = 0

        # making tetrominoes fall

        for i in range(20):

            for j in range(10):

                if gameboard[-2-i][j] == 3:

                    if gameboard[-1-i][j] == 0:
                        gameboard[-1-i][j] = 3
                        gameboard[-2-i][j] = 0

                    if gameboard[-1-i][j] != 3:
                        gameboard[-2-i][j] = 1
                        finishedFalling = True
                        recentlyCleared = False

                    if board20[j] == 3:
                        finishedFalling = True

        
        # making sure if one stops, all stop and summons the next tetromino

        if finishedFalling:

            for i in range(20):

                for j in range(10):

                    if gameboard[i][j] == 3:
                        gameboard[i][j] = 0
                        gameboard[i-1][j] = 1

            finishedFalling = False

            blockId = random.randint(1, 7)
            currentRotation = 1
            unmovableLeft = False
            unmovableRight = False

        
        # binding controls

        for event in events:

            if event.type == pygame.KEYDOWN:

                # moving left
                if event.key == pygame.K_LEFT and unmovableLeft is False:

                    for i in range(20):

                        for j in range(10):

                            if gameboard[i][j] == 3 and gameboard[i][j-1] == 0:
                                gameboard[i][j-1] = 3
                                gameboard[i][j] = 0
                                unmovableRight = False

                                if gameboard[i][j-1] == 1:
                                    unmovableLeft = True

                        if gameboard[i][0] == 3:
                            unmovableLeft = True

                # moving right
                if event.key == pygame.K_RIGHT and unmovableRight is False:

                    for i in range(20):

                        for j in range(10):

                            if gameboard[i][-1-j] == 3 and gameboard[i][0-j] == 0:
                                gameboard[i][0-j] = 3
                                gameboard[i][-1-j] = 0
                                unmovableLeft = False

                                if j != 9:
                                    if gameboard[i][j+1] == 1:
                                        unmovableRight = True

                        if gameboard[i][-1] == 3:
                            unmovableRight = True

                # rotating
                if event.key == pygame.K_UP and recentlyCleared is False:
                    
                    # rotating the I piece
                    
                    if rotationID == 1:
                        finishedRotating = False

                        for i in range(20):
                            for j in range(10):

                                if gameboard[i][j] == 3:
                                    
                                    # rotating the tall I to the long I
                                
                                    if orientation == 1 or orientation == 3:

                                        try:
                                            if gameboard[i-1][j+1] == 0 and gameboard[i+1][j+1] == 0 and gameboard[i+2][j+1] == 0 and finishedRotating is False:

                                                gameboard[i][j] = 0
                                                gameboard[i][j+2] = 0
                                                gameboard[i][j+3] = 0
                                        
                                                gameboard[i-1][j+1] = 3
                                                gameboard[i+1][j+1] = 3
                                                gameboard[i+2][j+1] = 3

                                                finishedRotating = True
                                        
                                        except:
                                            print("Out of range!")


                                    if orientation == 2 or orientation == 4:

                                        try:
                                            if gameboard[i+1][j-1] == 0 and gameboard[i+1][j+1] == 0 and gameboard[i+1][j+2] == 0 and finishedRotating is False:
    
                                                gameboard[i][j] = 0
                                                gameboard[i+2][j] = 0
                                                gameboard[i+3][j] = 0                                            
                                                
                                                gameboard[i+1][j-1] = 3
                                                gameboard[i+1][j+1] = 3
                                                gameboard[i+1][j+2] = 3
    
                                                finishedRotating = True
                                                
                                        except:
                                            print("Out of range!")
                                    
                        orientation += 1
                    
                    #rotating the J piece
                    
                    if rotationID == 2:
                        finishedRotating = False

                        for i in range(20):
                            for j in range(10):

                                if gameboard[i][j] == 3:
                                    
                                    if orientation == 1:
                                        
                                        try:
                                            if gameboard[i+1][j] == 0 and gameboard[i+1][j+1] == 0 and gameboard[i-1][j+1] == 0 and finishedRotating is False:
                                                
                                                gameboard[i][j] = 0
                                                gameboard[i][j+2] = 0
                                                gameboard[i+1][j+2] = 0
                                                
                                                gameboard[i+1][j] = 3
                                                gameboard[i+1][j+1] = 3
                                                gameboard[i-1][j+1] = 3
                                                finishedRotating = True
                                        
                                        except:
                                            print("Out of range!")
                                    
                                    if orientation == 2:
                                        
                                        try:
                                            if gameboard[i+1][j-1] == 0 and gameboard[i+2][j+1] == 0 and finishedRotating is False:
                                                
                                                gameboard[i][j] = 0
                                                gameboard[i+1][j] = 0
                                                
                                                gameboard[i+1][j-1] = 3
                                                gameboard[i+2][j+1] = 3
                                                finishedRotating = True
                                                
                                        except:
                                            print("Out of range!")                                        
                                            
                                    if orientation == 3:
                                        
                                        try:
                                            if gameboard[i-1][j] == 0 and gameboard[i-1][j+1] == 0 and finishedRotating is False:
                                                
                                                gameboard[i+1][j+1] = 0
                                                gameboard[i+1][j+2] = 0
                                                
                                                gameboard[i-1][j] = 3
                                                gameboard[i-1][j+1] = 3
                                                finishedRotating = True
                                        
                                        except:
                                            print("Out of range!")                                        
                                            
                                    if orientation == 4:
                                        try:
                                            if gameboard[i+1][j+1] == 0 and gameboard[i+1][j+2] == 0 and gameboard[i+2][j+2] == 0 and finishedRotating is False:
                                                
                                                gameboard[i][j] = 0
                                                gameboard[i][j+1] = 0
                                                gameboard[i+2][j] = 0
                                                
                                                gameboard[i+1][j+1] = 3
                                                gameboard[i+1][j+2] = 3
                                                gameboard[i+2][j+2] = 3
                                                finishedRotating = True
                                        
                                        except:
                                            print("Out of range!")                                        
                        
                        orientation += 1
                    
                    # rotating the L piece
                    if rotationID == 3:
                        finishedRotating = False

                        for i in range(20):
                            for j in range(10):

                                if gameboard[i][j] == 3:

                                    if orientation == 1:
                                        try:
                                            if gameboard[i-1][j] == 0 and gameboard[i+1][j+1] == 0 and gameboard[i-1][j+1] == 0 and finishedRotating is False:
    
                                                gameboard[i][j] = 0
                                                gameboard[i][j+2] = 0
                                                gameboard[i+1][j] = 0
    
                                                gameboard[i-1][j] = 3
                                                gameboard[i+1][j+1] = 3
                                                gameboard[i-1][j+1] = 3
                                                finishedRotating = True
                                        
                                        except:
                                            print("Out of range!")                                        
                        
                                    if orientation == 2:
                                        try:
                                            if gameboard[i+1][j+2] == 0 and gameboard[i+2][j] == 0 and gameboard[i+2][j+2] == 0 and finishedRotating is False:
    
                                                gameboard[i][j] = 0
                                                gameboard[i][j+1] = 0
                                                gameboard[i+1][j+1] = 0
    
                                                gameboard[i+1][j+2] = 3
                                                gameboard[i+2][j] = 3
                                                gameboard[i+2][j+2] =3
                                                finishedRotating = True
                                        
                                        except:
                                            print("Out of range!")                                        

                                    if orientation == 3:
                                        try:
                                            if gameboard[i-1][j-2] == 0 and gameboard[i][j-2] == 0 and finishedRotating is False:
    
                                                gameboard[i][j] = 0
                                                gameboard[i+1][j] = 0
    
                                                gameboard[i][j-2] = 3
                                                gameboard[i-1][j-2] = 3
                                                finishedRotating = True
                                        except:
                                            print("Out of range!")                                        

                                    if orientation == 4:
                                        try:
                                            if gameboard[i+1][j+1] == 0 and gameboard[i+1][j+2] == 0 and finishedRotating is False:
    
                                                gameboard[i][j] = 0
                                                gameboard[i+2][j+1] = 0
    
                                                gameboard[i+1][j+1] = 3
                                                gameboard[i+1][j+2] = 3
                                                finishedRotating = True
                                        
                                        except:
                                            print("Out of range!")                                        


                        orientation += 1
                    
                    # the O piece
                    if rotationID == 4:
                        print("O piece can't be rotated")
                        orientation += 1
                        
                    # the S piece
                    
                    if rotationID == 5:
                        
                        finishedRotating = False
                        
                        for i in range(20):
                            for j in range(10):
                                
                                if gameboard[i][j] == 3:
                                
                                    if orientation == 1 or orientation == 3:
            
                                        try:
                                            if gameboard[i][j-1] == 0 and gameboard[i-1][j-1] == 0 and finishedRotating is False:
                                    
                                                gameboard[i][j+1] = 0
                                                gameboard[i+1][j-1] = 0
                                    
                                                gameboard[i][j-1] = 3
                                                gameboard[i-1][j-1] = 3
                                    
                                                finishedRotating = True
                                    
                                        except:
                                            print("Out of range!")
                                    
                                    
                                    if orientation == 2 or orientation == 4:
                                    
                                        try:
                                            if gameboard[i+2][j] == 0 and gameboard[i+1][j+2] == 0 and finishedRotating is False:
                                    
                                                gameboard[i][j] = 0
                                                gameboard[i+1][j] = 0                                      
                                    
                                                gameboard[i+2][j] = 3
                                                gameboard[i+1][j+2] = 3
                                    
                                                finishedRotating = True
                                    
                                        except:
                                            print("Out of range!")
                                    
                        orientation += 1
                    
                    # the Z piece
                    if rotationID == 6:
                        
                        finishedRotating = False
                        
                        for i in range(20):
                            for j in range(10):
                                
                                if gameboard[i][j] == 3:
                                
                                    if orientation == 1 or orientation == 3:
                                
                                        try:
                                            if gameboard[i+1][j] == 0 and gameboard[i-1][j+1] == 0 and finishedRotating is False:
                                
                                                gameboard[i+1][j+1] = 0
                                                gameboard[i+1][j+2] = 0
                                
                                                gameboard[i-1][j+1] = 3
                                                gameboard[i+1][j] = 3
                                
                                                finishedRotating = True
                                
                                        except:
                                            print("Out of range!")
                                
                                
                                    if orientation == 2 or orientation == 4:
                                
                                        try:
                                            if gameboard[i+2][j] == 0 and gameboard[i+2][j+1] == 0 and finishedRotating is False:
                                
                                                gameboard[i][j] = 0
                                                gameboard[i+2][j-1] = 0                                      
                                
                                                gameboard[i+2][j] = 3
                                                gameboard[i+2][j+1] = 3
                                
                                                finishedRotating = True
                                
                                        except:
                                            print("Out of range!")                        
                        orientation += 1
                    
                    # the T piece
                    
                    if rotationID == 7:
                        
                        finishedRotating = False
                    
                        for i in range(20):
                            for j in range(10):
                    
                                if gameboard[i][j] == 3:
                                                                        
                                    if orientation == 1:
                                        try:
                                            if gameboard[i-1][j] == 0 and gameboard[i][j+1] == 0 and finishedRotating is False:
                                
                                                gameboard[i+1][j-1] = 0
                                                gameboard[i+1][j+1] = 0
                                
                                                gameboard[i-1][j] = 3
                                                gameboard[i][j+1] = 3
                                                finishedRotating = True
                                        except:
                                            print("Out of range!")                                        
                                
                                    if orientation == 2:
                                        try:
                                            if gameboard[i+1][j-1] == 0 and finishedRotating is False:
                                
                                                gameboard[i][j] = 0
                                
                                                gameboard[i+1][j-1] = 3
                                                finishedRotating = True
                                
                                        except:
                                            print("Out of range!")                                     
                    
                                    if orientation == 3:
                                        try:
                                            if gameboard[i-1][j+1] == 0 and finishedRotating is False:
                    
                                                gameboard[i][j+2] = 0
                    
                                                gameboard[i-1][j+1] = 3
                                                finishedRotating = True
                    
                                        except:
                                            print("Out of range!")                                        
                    
                                    if orientation == 4:
                                        try:
                                            if gameboard[i+2][j-1] == 0 and gameboard[i+2][j+1] == 0 and finishedRotating is False:
                    
                                                gameboard[i][j] = 0
                                                gameboard[i+1][j-1] = 0
                    
                                                gameboard[i+2][j-1] = 3
                                                gameboard[i+2][j+1] = 3
                                                finishedRotating = True
                    
                                        except:
                                            print("Out of range!")                                        
                    
                                                                                               
                        orientation += 1
                    
                    #reseting the block orientation back to 1 when it completes a full rotation
                    if orientation == 5:
                        orientation = 1
                        
        # displaying score
        font = pygame.font.Font('freesansbold.ttf', 32)

        scoreSTR = str(score)
        displayedScore = font.render(scoreSTR, True, (255, 255, 255))

        win.blit(displayedScore, (400, 200))

        # update the display
        pygame.display.update()
        pygame.time.wait(100)


    pygame.quit

# The title screen


def TitleScreen():

    run = True
    runSpeed = 10

    while run:
        pygame.time.delay(runSpeed)

        # Determining events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_RETURN:
                    mainGameLoop()
                    run = False


        # setting the background, which includes everything

        backgroundImage = pygame.image.load(os.path.join('Tetris_Home.png'))

        win.blit(backgroundImage, (0, 0))

        

        # update the display
        pygame.display.update()

    pygame.quit


def endGame():
    run = True
    runSpeed = 10

    while run:
        pygame.time.delay(runSpeed)

        # Determining events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_RETURN:
                    mainGameLoop()
                    run = False

        # Creating the font to write with
        font = pygame.font.Font('freesansbold.ttf', 32)

        # setting the background

        backgroundImage = pygame.image.load(os.path.join('Tetris_Endpage.png'))

        win.blit(backgroundImage, (0, 0))

        
        # drawing the score

        scoreText = font.render(str(scoreSTR), True, (255, 255, 255))

        win.blit(scoreText, (220, 300))

        # update the display
        pygame.display.update()

    pygame.quit


# the actual program
pygame.mixer.init()
pygame.mixer.music.load(os.path.join('Tetris_Theme.wav'))
pygame.mixer.music.play(-1)

TitleScreen()